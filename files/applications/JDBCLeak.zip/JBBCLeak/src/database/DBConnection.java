/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

//This class was based on this example: https://docs.oracle.com/middleware/1213/wls/JDBCP/programming.htm#JDBCP119
import java.sql.*;
import java.util.*;
import javax.naming.*;

/**
 *
 * @author SyscoUser
 */
public class DBConnection {
    private Hashtable ht=new Hashtable();
    private Connection conn = null;
    private Statement stmt = null;
    private ResultSet rs = null;
    private Context ctx = null;
    
    public DBConnection(String urlProvider){
         ht.put(Context.INITIAL_CONTEXT_FACTORY,
         "weblogic.jndi.WLInitialContextFactory");
         ht.put(Context.PROVIDER_URL,
         urlProvider);
    }
    
    public void establishConnection(String dataSourceName){
        try {
            ctx = new InitialContext(ht);
            javax.sql.DataSource ds 
              = (javax.sql.DataSource) ctx.lookup(dataSourceName);
            conn = ds.getConnection();
           // You can now use the conn object to create 
           //  Statements and retrieve result sets:
            stmt = conn.createStatement();
            //stmt.execute("select * from dual");
            //rs = stmt.getResultSet(); 

        //Close JDBC objects as soon as possible
            //stmt.close();
            //stmt=null;
            //conn.close();
            //conn=null;
         }
        catch (Exception e) {
            e.printStackTrace();
          // a failure occurred
          //log message;

            //ctx.close(); 
            //if (rs != null) rs.close(); 
            //if (stmt != null) stmt.close(); 
            //if (conn != null) conn.close(); 
        }
        finally {    
        try { 
          //ctx.close(); 
        } catch (Exception e) {
           //log message; 
            e.printStackTrace();
               }
        try { 
          //if (rs != null) rs.close(); 
        } catch (Exception e) {  
           //log message; 
            e.printStackTrace();
               }
        try { 
          //if (stmt != null) stmt.close(); 
        } catch (Exception e) {  
           //log message; 
            e.printStackTrace();
               }
        try { 
          //if (conn != null) conn.close(); 
        } catch (Exception e) {  
           //log message; 
            e.printStackTrace();
                }
      }
        
    }

}
