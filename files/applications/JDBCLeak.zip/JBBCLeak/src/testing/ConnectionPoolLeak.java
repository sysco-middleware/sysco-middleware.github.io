/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testing;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import monitoring.JDBCMonitoring;
import monitoring.JMXConnection;
import monitoring.ServerMonitoring;
import GUI.ScreenConnection;

/**
 *
 * @author SyscoUser
 */
public class  ConnectionPoolLeak {
    

    
    public static void test(){
        JMXConnection con=new JMXConnection("weblogic", "", "admin12c.sysco.no", "9001", "t3");
        MBeanServerConnection con1=con.getConnection();

        ServerMonitoring sm= new ServerMonitoring();

        ObjectName listServers[]=sm.getListServers(con1);
        
        int max = (int) listServers.length;
        
        JDBCMonitoring jdbcMon=new JDBCMonitoring();
        
        for (int i = 0; i < max; i++) {
            try{
                String name = (String) con1.getAttribute(listServers[i],"Name");
                System.out.println(name);
                                                                               
                ObjectName listDS[]=jdbcMon.getListDS(name, con1);
                
                if (listDS!=null){
                    for (int j = 0; j < listDS.length; j++) {
                        {
                            String nameDS = (String) con1.getAttribute(listDS[j],"Name");
                            System.out.println(nameDS);  
                            jdbcMon.refreshAttributes(con1, listDS[j]);
                            System.out.println("Active Connections Average: "+jdbcMon.getActiveConnectionsAverageCount());
                            System.out.println("Available Connections: "+jdbcMon.getNumAvailable());
                        }
                    }    
                }
                                
            }                        
            catch (Exception e){
                e.printStackTrace();
            }            
        }
    }
    
   /* public static void main(String [] args)
	{
		//test();
            ScreenConnection g =new ScreenConnection();
            g.setVisible(true);
         
	}*/
    

}
