/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package monitoring;

import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import javax.management.*;
import javax.naming.*;
import java.util.HashMap;
/**
 *
 * @author SyscoUser
 */
public class JMXConnection {
    private MBeanServerConnection connection;
    private String domainName;
    private JMXConnector connector;
    private MBeanServerConnection connectionConfig;
    private JMXConnector connectorConfig;
    private String user;
    private String password;
    private String hostname;
    private int port;
    private String protocol;
    
    public JMXConnection(String user, String password, String hostname, String port, String protocol){
        
        this.user=user;
        this.password=password;
        this.hostname=hostname;
        this.port=Integer.valueOf(port);
        this.protocol=protocol;               
    }
    
    public MBeanServerConnection getConnection() {
        String jndiroot = "/jndi/";
        String runTime = "weblogic.management.mbeanservers.domainruntime";        
        HashMap h = new HashMap();
        h.put(Context.SECURITY_PRINCIPAL, this.user);
        h.put(Context.SECURITY_CREDENTIALS, this.password);
        h.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES,"weblogic.management.remote");

        try
        {
          JMXServiceURL serviceURL = new JMXServiceURL(this.protocol, this.hostname, this.port, jndiroot + runTime);
          connector = JMXConnectorFactory.connect(serviceURL, h);
          connection = connector.getMBeanServerConnection(); 
          domainName=connection.getDefaultDomain();
        }
        catch(Exception e)
        {
          e.printStackTrace();      
        }
       /* finally{
            try{
                connector.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();      
            }
        }*/
        return connection; 
        
    } 
    
    /*public MBeanServerConnection getConnectionConfig() {
        String jndiroot = "/jndi/";
        String runTime = "weblogic.management.mbeanservers.domainruntime";        
        HashMap h = new HashMap();
        h.put(Context.SECURITY_PRINCIPAL, this.user);
        h.put(Context.SECURITY_CREDENTIALS, this.password);
        h.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES,"weblogic.management.remote");

        try
        {
          JMXServiceURL serviceURL = new JMXServiceURL(this.protocol, this.hostname, this.port, jndiroot + runTime);
          connectorConfig = JMXConnectorFactory.connect(serviceURL, h);
          connectionConfig = connector.getMBeanServerConnection();         
        }
        catch(Exception e)
        {
          e.printStackTrace();      
        }

        return connection; 
        
    }*/
    
    public String getUser()
    {
        return this.user;
    }
    public String geDomainName()
    {
        return this.domainName;
    }
    public String getPassword()
    {
        return this.password;
    }
    
    public String getHostName()
    {
        return this.hostname;
    }
    
    public int getPort()
    {
        return this.port;
    }
    
    public String getProtocol()
    {
        return this.protocol;
    }    
}
