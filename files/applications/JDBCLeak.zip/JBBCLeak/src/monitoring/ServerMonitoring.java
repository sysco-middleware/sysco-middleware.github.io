/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monitoring;

/**
 *
 * @author SyscoUser
 */
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;


public class ServerMonitoring {
    
    private ObjectName listServers[];
    private static String combea = "com.bea:Name=";
    private static String service = "DomainRuntimeService,Type=weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean";
    
    public ObjectName [] getListServers(MBeanServerConnection connection){
        try{     
        ObjectName temp =new ObjectName(combea + service);
        
        listServers =(ObjectName[])connection.getAttribute(temp,"ServerRuntimes");
        
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return listServers;
    }
}
