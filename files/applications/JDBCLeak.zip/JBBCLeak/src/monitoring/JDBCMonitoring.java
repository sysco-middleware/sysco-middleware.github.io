/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monitoring;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

/**
 *
 * @author SyscoUser
 */
public class JDBCMonitoring {
    private ObjectName[] listDataSources;
    private String[] JNDINames;

    private String nameDS;
    private String ActiveConnectionsAverageCount;
    private String ActiveConnectionsCurrentCount;
    private String ActiveConnectionsHighCount;
    private String ConnectionDelayTime;
    private String ConnectionsTotalCount;
    private String CurrCapacity;
    private String CurrCapacityHighCount;

    private String FailedReserveRequestCount;
    private String FailuresToReconnectCount;
    private String NumAvailable;
    private String NumUnavailable;
    private String LeakedConnectionCount;
    private String State;
    private String WaitingForConnectionCurrentCount; 
    
    
    
    public void JDBCMonitoring(MBeanServerConnection connection, ObjectName dataSourceName){
        try {        
            nameDS=connection.getAttribute(dataSourceName, "Name").toString();

            ActiveConnectionsAverageCount=connection.getAttribute(dataSourceName,"ActiveConnectionsAverageCount").toString();
            ActiveConnectionsCurrentCount=connection.getAttribute(dataSourceName,"ActiveConnectionsCurrentCount").toString();
            ActiveConnectionsHighCount=connection.getAttribute(dataSourceName,"ActiveConnectionsHighCount").toString();
            ConnectionDelayTime=connection.getAttribute(dataSourceName,"ConnectionDelayTime").toString();
            ConnectionsTotalCount=connection.getAttribute(dataSourceName,"ConnectionsTotalCount").toString();
            CurrCapacity=connection.getAttribute(dataSourceName,"CurrCapacity").toString();
            CurrCapacityHighCount=connection.getAttribute(dataSourceName,"CurrCapacityHighCount").toString();

            FailedReserveRequestCount=connection.getAttribute(dataSourceName,"FailedReserveRequestCount").toString();
            FailuresToReconnectCount=connection.getAttribute(dataSourceName,"FailuresToReconnectCount").toString();
            NumAvailable=connection.getAttribute(dataSourceName,"NumAvailable").toString();
            NumUnavailable=connection.getAttribute(dataSourceName,"NumUnavailable").toString();
            LeakedConnectionCount=connection.getAttribute(dataSourceName,"LeakedConnectionCount").toString();
            State=connection.getAttribute(dataSourceName,"State").toString();
            WaitingForConnectionCurrentCount=connection.getAttribute(dataSourceName,"WaitingForConnectionCurrentCount").toString();
         
        }
        catch (Exception e){
            e.printStackTrace();
        }            
    }
    public void refreshAttributes(MBeanServerConnection connection, ObjectName dataSourceName){
        try {        
            nameDS=connection.getAttribute(dataSourceName, "Name").toString();
            ActiveConnectionsAverageCount=connection.getAttribute(dataSourceName,"ActiveConnectionsAverageCount").toString();
            ActiveConnectionsCurrentCount=connection.getAttribute(dataSourceName,"ActiveConnectionsCurrentCount").toString();
            ActiveConnectionsHighCount=connection.getAttribute(dataSourceName,"ActiveConnectionsHighCount").toString();
            ConnectionDelayTime=connection.getAttribute(dataSourceName,"ConnectionDelayTime").toString();
            ConnectionsTotalCount=connection.getAttribute(dataSourceName,"ConnectionsTotalCount").toString();
            CurrCapacity=connection.getAttribute(dataSourceName,"CurrCapacity").toString();
            CurrCapacityHighCount=connection.getAttribute(dataSourceName,"CurrCapacityHighCount").toString();
            FailedReserveRequestCount=connection.getAttribute(dataSourceName,"FailedReserveRequestCount").toString();
            FailuresToReconnectCount=connection.getAttribute(dataSourceName,"FailuresToReconnectCount").toString();
            NumAvailable=connection.getAttribute(dataSourceName,"NumAvailable").toString();
            NumUnavailable=connection.getAttribute(dataSourceName,"NumUnavailable").toString();
            LeakedConnectionCount=connection.getAttribute(dataSourceName,"LeakedConnectionCount").toString();
            State=connection.getAttribute(dataSourceName,"State").toString();
            WaitingForConnectionCurrentCount=connection.getAttribute(dataSourceName,"WaitingForConnectionCurrentCount").toString();         
        }
        catch (Exception e){
            e.printStackTrace();
        }            
    }    
    public ObjectName [] getListDS(String serverName, MBeanServerConnection connection){
        try{
            String service="com.bea:ServerRuntime="+serverName+",Name="+serverName+",Location="+serverName+",Type=JDBCServiceRuntime";
            //ObjectName temp =new ObjectName("com.bea:ServerRuntime="+serverName+",Name="+serverName+",Location="+serverName+",Type=JDBCServiceRuntime");
            ObjectName temp =new ObjectName(service);
        
            listDataSources=  (ObjectName[])connection.getAttribute(temp,"JDBCDataSourceRuntimeMBeans");        
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return listDataSources;
    }
    
    public String getJNDINames(String dataSourceName, String domainName, MBeanServerConnection connection){
        try{
            String service="com.bea:Name="+dataSourceName+",Location="+domainName+",Type=weblogic.j2ee.descriptor.wl.JDBCDataSourceParamsBean,Parent=["+
                            domainName+"]/JDBCSystemResources["+dataSourceName+"],Path=JDBCResource["+dataSourceName+"]/JDBCDataSourceParams";
            
            //ObjectName temp =new ObjectName("com.bea:ServerRuntime="+serverName+",Name="+serverName+",Location="+serverName+",Type=JDBCServiceRuntime");
            ObjectName temp =new ObjectName(service);
        
            JNDINames=  (String[])connection.getAttribute(temp,"JNDINames");        
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return JNDINames[0];
    }
    
    public String getActiveConnectionsAverageCount() {
        return ActiveConnectionsAverageCount;
    }    

    public String getActiveConnectionsCurrentCount() {
        return ActiveConnectionsCurrentCount;
    }

    public String getActiveConnectionsHighCount() {
        return ActiveConnectionsHighCount;
    }

    public String getConnectionDelayTime() {
        return ConnectionDelayTime;
    }

    public String getConnectionsTotalCount() {
        return ConnectionsTotalCount;
    }

    public String getCurrCapacityHighCount() {
        return CurrCapacityHighCount;
    }

    public String getCurrCapacity() {
        return CurrCapacity;
    }

    public String getFailedReserveRequestCount() {
        return FailedReserveRequestCount;
    }

    public String getFailuresToReconnectCount() {
        return FailuresToReconnectCount;
    }

    public String getLeakedConnectionCount() {
        return LeakedConnectionCount;
    }

    public ObjectName[] getListDataSources() {
        return listDataSources;
    }

    public String getNumAvailable() {
        return NumAvailable;
    }

    public String getNumUnavailable() {
        return NumUnavailable;
    }

    public String getWaitingForConnectionCurrentCount() {
        return WaitingForConnectionCurrentCount;
    }
    
    public String getNameDS() {
        return nameDS;
    }
    
    public String getState() {
        return State;
    }
    
}
