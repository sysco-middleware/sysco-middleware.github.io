/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monitoring;

/**
 *
 * @author SyscoUser
 */
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

public class DomainConfig {
    
    private ObjectName listServers[];
    private static String combea = "com.bea:Name=";
    private static String service = "DomainRuntimeService,Type=weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean";
    
    
    
}
