package application;

import java.util.Random;

import oracle.adfmf.java.beans.PropertyChangeListener;
import oracle.adfmf.java.beans.PropertyChangeSupport;
import oracle.adfmf.java.beans.ProviderChangeListener;
import oracle.adfmf.java.beans.ProviderChangeSupport;

public class TableSum {
    
    
    CellNumber[] TableRow1 = new CellNumber[5];
    CellNumber[] TableRow2 = new CellNumber[5];
    CellNumber[] TableRow3 = new CellNumber[5];
    CellNumber[] TableRow4 = new CellNumber[5];
    CellNumber[] TableRow5 = new CellNumber[5];
    CellNumber[] TableRow6 = new CellNumber[5];
    CellNumber[] TableRow7 = new CellNumber[5];
    CellNumber[] TableRow8 = new CellNumber[5];
    CellNumber[] TableRow9 = new CellNumber[5];
    CellNumber[] TableRow10 = new CellNumber[5];
    String resultSum="";
    
    CellNumber[][] FullTable= new CellNumber[10][5];
    
    protected transient ProviderChangeSupport providerChangeSupport = new ProviderChangeSupport(this);
    private transient PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

    public TableSum() {
        super();
        Random randomNumber= new Random();
        for (int i=0;i<5;i++){
            TableRow1[i]=new CellNumber(randomNumber.nextInt()%20*(randomNumber.nextBoolean()?1:-1)+"","Black");            
            TableRow2[i]=new CellNumber(randomNumber.nextInt()%20*(randomNumber.nextBoolean()?1:-1)+"","Black");
            TableRow3[i]=new CellNumber(randomNumber.nextInt()%20*(randomNumber.nextBoolean()?1:-1)+"","Black");
            TableRow4[i]=new CellNumber(randomNumber.nextInt()%20*(randomNumber.nextBoolean()?1:-1)+"","Black");
            TableRow5[i]=new CellNumber(randomNumber.nextInt()%20*(randomNumber.nextBoolean()?1:-1)+"","Black");
            TableRow6[i]=new CellNumber(randomNumber.nextInt()%20*(randomNumber.nextBoolean()?1:-1)+"","Black");
            TableRow7[i]=new CellNumber(randomNumber.nextInt()%20*(randomNumber.nextBoolean()?1:-1)+"","Black");
            TableRow8[i]=new CellNumber(randomNumber.nextInt()%20*(randomNumber.nextBoolean()?1:-1)+"","Black");
            TableRow9[i]=new CellNumber(randomNumber.nextInt()%20*(randomNumber.nextBoolean()?1:-1)+"","Black");
            TableRow10[i]=new CellNumber(randomNumber.nextInt()%20*(randomNumber.nextBoolean()?1:-1)+"","Black");
        }
        
        FullTable[0]=TableRow1;
        FullTable[1]=TableRow2;
        FullTable[2]=TableRow3;
        FullTable[3]=TableRow4;
        FullTable[4]=TableRow5;
        FullTable[5]=TableRow6;
        FullTable[6]=TableRow7;
        FullTable[7]=TableRow8;
        FullTable[8]=TableRow9;
        FullTable[9]=TableRow10;
        
    }
    
    
    
    
    
    public void runAlgorithm(){
        // Modify the array's elements to now hold the sum  
                // of all the numbers that are above that element in its column 
        int N=10,M=5;
        int max_ending_here, max_so_far, maximum = Integer.MIN_VALUE;
        int xBottom=0,yBottom=0,xTop=0,yTop=0;
        int xBottomAux=0,yBottomAux=0,xTopAux=0,yTopAux=0,yTopAuxOld=0,yTopAuxNew=0;

            for (int startx = 0; startx < N; startx++) {
                int [] sum= new int[N];
                for (int x = startx; x < N; x++) {
                    max_ending_here = 0;
                    max_so_far = Integer.MIN_VALUE;
                    yTopAuxOld=0;yTopAuxNew=0;
                    
                    for (int y = 0; y < M; y++) {
                        sum[y] += new Integer(FullTable[x][y].getNumber());
                        
                        max_ending_here = Math.max(0, max_ending_here + sum[y]);
                        if (0==max_ending_here){
                        
                            yTopAuxNew=y+1<M?y+1:yTopAuxOld;
                        }
                        if (max_so_far<max_ending_here){
                            xTopAux=startx;
                            xBottomAux=x;
                            yBottomAux=y;
                            yTopAux=yTopAuxOld;
                            yTopAuxOld=yTopAuxNew;
                        }
                        
                        max_so_far = Math.max(max_so_far, max_ending_here);
                    }
                    if (max_so_far>maximum){
                        xTop=xTopAux;
                        xBottom=xBottomAux;
                        yTop=yTopAux;
                        yBottom=yBottomAux;
                        
                    }    
                    maximum = Math.max(maximum, max_so_far);
                }
            }
        propertyChangeSupport.firePropertyChange("resultSum", "zz", maximum +" ("+xTop+","+yTop+") ("+xBottom+","+yBottom+")");     
        paintResult(xTop,yTop,xBottom,yBottom);
    }
    public void paintResult(int xTop,int yTop,int xBottom,int yBottom){
        for (int i=0;i<5;i++){
            TableRow1[i]=new CellNumber(FullTable[0][i].getNumber(),"Black");            
            TableRow2[i]=new CellNumber(FullTable[1][i].getNumber(),"Black");
            TableRow3[i]=new CellNumber(FullTable[2][i].getNumber(),"Black");
            TableRow4[i]=new CellNumber(FullTable[3][i].getNumber(),"Black");
            TableRow5[i]=new CellNumber(FullTable[4][i].getNumber(),"Black");
            TableRow6[i]=new CellNumber(FullTable[5][i].getNumber(),"Black");
            TableRow7[i]=new CellNumber(FullTable[6][i].getNumber(),"Black");
            TableRow8[i]=new CellNumber(FullTable[7][i].getNumber(),"Black");
            TableRow9[i]=new CellNumber(FullTable[8][i].getNumber(),"Black");
            TableRow10[i]=new CellNumber(FullTable[9][i].getNumber(),"Black");
        }
        
        for (int x=xTop;x<=xBottom;x++){
            for (int y=yTop;y<=yBottom;y++){
                FullTable[x][y].setColor("Blue");
                if (x==0)TableRow1[y].setColor("Blue");
                if (x==1)TableRow2[y].setColor("Blue");
                if (x==2)TableRow3[y].setColor("Blue");
                if (x==3)TableRow4[y].setColor("Blue");
                if (x==4)TableRow5[y].setColor("Blue");
                if (x==5)TableRow6[y].setColor("Blue");
                if (x==6)TableRow7[y].setColor("Blue");
                if (x==7)TableRow8[y].setColor("Blue");
                if (x==8)TableRow9[y].setColor("Blue");
                if (x==9)TableRow10[y].setColor("Blue");
            }
        }
        /*TableRow1=FullTable[0];
        TableRow2=FullTable[1];
        TableRow3=FullTable[2];
        TableRow4=FullTable[3];
        TableRow5=FullTable[4];
        TableRow6=FullTable[5];
        TableRow7=FullTable[6];
        TableRow8=FullTable[7];
        TableRow9=FullTable[8];
        TableRow10=FullTable[9];*/
        
        providerChangeSupport.fireProviderRefresh("tableRow1");
        providerChangeSupport.fireProviderRefresh("tableRow2");
        providerChangeSupport.fireProviderRefresh("tableRow3");
        providerChangeSupport.fireProviderRefresh("tableRow4");
        providerChangeSupport.fireProviderRefresh("tableRow5");
        providerChangeSupport.fireProviderRefresh("tableRow6");
        providerChangeSupport.fireProviderRefresh("tableRow7");
        providerChangeSupport.fireProviderRefresh("tableRow8");
        providerChangeSupport.fireProviderRefresh("tableRow9");
        providerChangeSupport.fireProviderRefresh("tableRow10");
        
    }
    public void addProviderChangeListener(ProviderChangeListener l) {
        providerChangeSupport.addProviderChangeListener(l);
    }

    public void removeProviderChangeListener(ProviderChangeListener l) {
        providerChangeSupport.removeProviderChangeListener(l);
    }
    public void addPropertyChangeListener(PropertyChangeListener l) {
        propertyChangeSupport.addPropertyChangeListener(l);
    }

    public void removePropertyChangeListener(PropertyChangeListener l) {
        propertyChangeSupport.removePropertyChangeListener(l);
    }
    public void setTableRow1(CellNumber[] TableRow1) {
        this.TableRow1 = TableRow1;
    }

    public CellNumber[] getTableRow1() {
        return TableRow1;
    }

    public void setTableRow2(CellNumber[] TableRow2) {
        this.TableRow2 = TableRow2;
    }

    public CellNumber[] getTableRow2() {
        return TableRow2;
    }

    public void setTableRow3(CellNumber[] TableRow3) {
        this.TableRow3 = TableRow3;
    }

    public CellNumber[] getTableRow3() {
        return TableRow3;
    }

    public void setTableRow4(CellNumber[] TableRow4) {
        this.TableRow4 = TableRow4;
    }

    public CellNumber[] getTableRow4() {
        return TableRow4;
    }

    public void setTableRow5(CellNumber[] TableRow5) {
        this.TableRow5 = TableRow5;
    }

    public CellNumber[] getTableRow5() {
        return TableRow5;
    }

    public void setTableRow6(CellNumber[] TableRow6) {
        this.TableRow6 = TableRow6;
    }

    public CellNumber[] getTableRow6() {
        return TableRow6;
    }

    public void setTableRow7(CellNumber[] TableRow7) {
        this.TableRow7 = TableRow7;
    }

    public CellNumber[] getTableRow7() {
        return TableRow7;
    }

    public void setTableRow8(CellNumber[] TableRow8) {
        this.TableRow8 = TableRow8;
    }

    public CellNumber[] getTableRow8() {
        return TableRow8;
    }

    public void setTableRow9(CellNumber[] TableRow9) {
        this.TableRow9 = TableRow9;
    }

    public CellNumber[] getTableRow9() {
        return TableRow9;
    }

    public void setTableRow10(CellNumber[] TableRow10) {
        this.TableRow10 = TableRow10;
    }

    public CellNumber[] getTableRow10() {
        return TableRow10;
    }

    public void setResultSum(String resultSum) {
        this.resultSum = resultSum;
    }

    public String getResultSum() {
        return resultSum;
    }
}
